exec ("./wrench/wrench.cs");
exec ("./hammer.cs");
exec ("./printGun/printGun.cs");
exec ("./sprayCan/sprayCan.cs");
exec ("./wand.cs");
exec ("./adminWand.cs");
exec ("./brickTool.cs");
